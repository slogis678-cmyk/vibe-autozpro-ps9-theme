{**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to https://devdocs.prestashop.com/ for more information.
 *
 * @author    PrestaShop SA and Contributors <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 *}
<div id="order-items" class="col-md-12">
  <div class="row">
    {block name='order_items_table_head'}
      <h3 class="card-title h3 col-md-6 col-12">{l s='Order items' d='Shop.Theme.Checkout'}</h3>
      <h3 class="card-title h3 col-md-2 text-md-center _desktop-title">{l s='Unit price' d='Shop.Theme.Checkout'}</h3>
      <h3 class="card-title h3 col-md-2 text-md-center _desktop-title">{l s='Quantity' d='Shop.Theme.Checkout'}</h3>
      <h3 class="card-title h3 col-md-2 text-md-center _desktop-title">{l s='Total products' d='Shop.Theme.Checkout'}</h3>
    {/block}
  </div>

  <div class="order-confirmation-table">
    {block name='order_confirmation_table'}
      {foreach from=$products['physical_products'] item=product}
        {foreach from=$product['products'] item=productDetail}
          <div class="order-line row">
            <div class="col-sm-2 col-xs-3">
              <span class="image">
                {if !empty($productDetail.default_image)}
                  <picture>
                    {if !empty($productDetail.default_image.medium.sources.avif)}<source srcset="{$productDetail.default_image.medium.sources.avif}" type="image/avif">{/if}
                    {if !empty($productDetail.default_image.medium.sources.webp)}<source srcset="{$productDetail.default_image.medium.sources.webp}" type="image/webp">{/if}
                    <img src="{$productDetail.default_image.medium.url}" loading="lazy" />
                  </picture>
                {else}
                  <picture>
                    {if !empty($urls.no_picture_image.bySize.medium_default.sources.avif)}<source srcset="{$urls.no_picture_image.bySize.medium_default.sources.avif}" type="image/avif">{/if}
                    {if !empty($urls.no_picture_image.bySize.medium_default.sources.webp)}<source srcset="{$urls.no_picture_image.bySize.medium_default.sources.webp}" type="image/webp">{/if}
                    <img src="{$urls.no_picture_image.bySize.medium_default.url}" loading="lazy" />
                  </picture>
                {/if}
              </span>
            </div>
            <div class="col-sm-4 col-xs-9 details">
              {if $add_product_link}<a href="{$productDetail.url}" target="_blank">{/if}
                <span>{$productDetail.name}</span>
              {if $add_product_link}</a>{/if}
              {if isset($product['carrier']) && $product['carrier'].name}
                <div class="carrier-name">{l s='Carrier: ' d='Shop.Theme.Checkout'} {$product['carrier'].name}</div>
              {/if}
              {if is_array($productDetail.customizations) && $productDetail.customizations|count}
                {foreach from=$productDetail.customizations item="customization"}
                  <div class="customizations">
                    <a href="#" data-toggle="modal" data-target="#product-customizations-modal-{$customization.id_customization}">{l s='Product customization' d='Shop.Theme.Catalog'}</a>
                  </div>
                  <div class="modal fade customization-modal" id="product-customizations-modal-{$customization.id_customization}" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-label="{l s='Close' d='Shop.Theme.Global'}">
                            <span aria-hidden="true">&times;</span>
                          </button>
                          <h4 class="modal-title">{l s='Product customization' d='Shop.Theme.Catalog'}</h4>
                        </div>
                        <div class="modal-body">
                          {foreach from=$customization.fields item="field"}
                            <div class="product-customization-line row">
                              <div class="col-sm-3 col-xs-4 label">
                                {$field.label}
                              </div>
                              <div class="col-sm-9 col-xs-8 value">
                                {if $field.type == 'text'}
                                  {if (int)$field.id_module}
                                    {$field.text nofilter}
                                  {else}
                                    {$field.text}
                                  {/if}
                                {elseif $field.type == 'image'}
                                  <img src="{$field.image.small.url}" loading="lazy">
                                {/if}
                              </div>
                            </div>
                          {/foreach}
                        </div>
                      </div>
                    </div>
                  </div>
                {/foreach}
              {/if}
              {hook h='displayProductPriceBlock' product=$productDetail type="unit_price"}
            </div>
            <div class="col-sm-6 col-xs-12 qty">
              <div class="row">
                <div class="col-xs-4 text-sm-center text-xs-left">{$productDetail.price}</div>
                <div class="col-xs-4 text-sm-center">{$productDetail.quantity}</div>
                <div class="col-xs-4 text-sm-center text-xs-right bold">{$productDetail.total}</div>
              </div>
            </div>
          </div>
        {/foreach}
      {/foreach}

      {if isset($products['virtual_products']) && !empty($products['virtual_products'])}
        {foreach from=$products['virtual_products'] item=productDetail}
          <div class="order-line row">
            <div class="col-sm-2 col-xs-3">
              <span class="image">
                {if !empty($productDetail.default_image)}
                  <picture>
                    {if !empty($productDetail.default_image.medium.sources.avif)}<source srcset="{$productDetail.default_image.medium.sources.avif}" type="image/avif">{/if}
                    {if !empty($productDetail.default_image.medium.sources.webp)}<source srcset="{$productDetail.default_image.medium.sources.webp}" type="image/webp">{/if}
                    <img src="{$productDetail.default_image.medium.url}" loading="lazy" />
                  </picture>
                {else}
                  <picture>
                    {if !empty($urls.no_picture_image.bySize.medium_default.sources.avif)}<source srcset="{$urls.no_picture_image.bySize.medium_default.sources.avif}" type="image/avif">{/if}
                    {if !empty($urls.no_picture_image.bySize.medium_default.sources.webp)}<source srcset="{$urls.no_picture_image.bySize.medium_default.sources.webp}" type="image/webp">{/if}
                    <img src="{$urls.no_picture_image.bySize.medium_default.url}" loading="lazy" />
                  </picture>
                {/if}
              </span>
            </div>
            <div class="col-sm-4 col-xs-9 details">
              {if $add_product_link}<a href="{$productDetail.url}" target="_blank">{/if}
                <span>{$productDetail.name}</span>
              {if $add_product_link}</a>{/if}

              <div class="virtual-info">{l s='Virtual product, no delivery service.' d='Shop.Theme.Global'}</div>

              {if is_array($productDetail.customizations) && $productDetail.customizations|count}
                {foreach from=$productDetail.customizations item="customization"}
                  <div class="customizations">
                    <a href="#" data-toggle="modal" data-target="#product-customizations-modal-{$customization.id_customization}">{l s='Product customization' d='Shop.Theme.Catalog'}</a>
                  </div>
                  <div class="modal fade customization-modal" id="product-customizations-modal-{$customization.id_customization}" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-label="{l s='Close' d='Shop.Theme.Global'}">
                            <span aria-hidden="true">&times;</span>
                          </button>
                          <h4 class="modal-title">{l s='Product customization' d='Shop.Theme.Catalog'}</h4>
                        </div>
                        <div class="modal-body">
                          {foreach from=$customization.fields item="field"}
                            <div class="product-customization-line row">
                              <div class="col-sm-3 col-xs-4 label">
                                {$field.label}
                              </div>
                              <div class="col-sm-9 col-xs-8 value">
                                {if $field.type == 'text'}
                                  {if (int)$field.id_module}
                                    {$field.text nofilter}
                                  {else}
                                    {$field.text}
                                  {/if}
                                {elseif $field.type == 'image'}
                                  <img src="{$field.image.small.url}" loading="lazy">
                                {/if}
                              </div>
                            </div>
                          {/foreach}
                        </div>
                      </div>
                    </div>
                  </div>
                {/foreach}
              {/if}
              {hook h='displayProductPriceBlock' product=$productDetail type="unit_price"}
            </div>
            <div class="col-sm-6 col-xs-12 qty">
              <div class="row">
                <div class="col-xs-4 text-sm-center text-xs-left">{$productDetail.price}</div>
                <div class="col-xs-4 text-sm-center">{$productDetail.quantity}</div>
                <div class="col-xs-4 text-sm-center text-xs-right bold">{$productDetail.total}</div>
              </div>
            </div>
          </div>
        {/foreach}
      {/if}

      <hr>

      <table>
        {foreach $subtotals as $subtotal}
          {if $subtotal !== null && $subtotal.type !== 'tax' && $subtotal.label !== null}
            <tr>
              <td>{$subtotal.label}</td>
              <td>{if 'discount' == $subtotal.type}-&nbsp;{/if}{$subtotal.value}</td>
            </tr>
          {/if}
        {/foreach}

        {if !$configuration.display_prices_tax_incl && $configuration.taxes_enabled}
          <tr>
            <td><span class="text-uppercase">{$totals.total.label}&nbsp;{$labels.tax_short}</span></td>
            <td>{$totals.total.value}</td>
          </tr>
          <tr class="total-value font-weight-bold">
            <td><span class="text-uppercase">{$totals.total_including_tax.label}</span></td>
            <td>{$totals.total_including_tax.value}</td>
          </tr>
        {else}
          <tr class="total-value font-weight-bold">
            <td><span class="text-uppercase">{$totals.total.label}&nbsp;{if $configuration.taxes_enabled && $configuration.display_taxes_label}{$labels.tax_short}{/if}</span></td>
            <td>{$totals.total.value}</td>
          </tr>
        {/if}
        {if $subtotals.tax !== null && $subtotals.tax.label !== null}
          <tr class="sub taxes">
            <td colspan="2"><span class="label">{l s='%label%:' sprintf=['%label%' => $subtotals.tax.label] d='Shop.Theme.Global'}</span>&nbsp;<span class="value">{$subtotals.tax.value}</span></td>
          </tr>
        {/if}
      </table>
    {/block}
  </div>
</div>
